---
name: Production database sync
description: The project’s development and production PostgreSQL data are separate and require an explicit publish-time copy.
---

Development and production database rows are separate. To move the seeded development records into the live database, use the publish flow’s “Set up your production database with your current development data” option.

**Why:** The live app can correctly call the API while still showing fewer rows because production may contain an older dataset. The copy operation replaces current production data and is irreversible.

**How to apply:** When debugging a live record-count mismatch, check both environments before changing frontend code; verify the development dataset first, then have the user confirm the publish-time production data replacement.

Automated requests to the published hostname may be redirected to Replit’s access shield even when the deployment is healthy. In that case, a production write through the public API cannot be completed by the agent; the user can submit through the live UI instead.

**Why:** The shield can block agent-side HTTP requests before they reach the application, while the user’s authenticated browser can still use the published app.

**How to apply:** Do not claim a production API write succeeded unless the response is verified; provide the user with the exact form values when the live endpoint is shielded.