# Civic Hazard Reporter

A small civic reporting demo where San José residents submit traffic or accessibility hazards and city officials review AI-assisted complaint drafts before approval.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 5000)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL` — Postgres connection string

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

- `artifacts/civic-hazard-reporter/src/App.tsx` — resident submission and official review flows
- `artifacts/civic-hazard-reporter/src/index.css` — app theme, typography, texture, and motion
- `artifacts/civic-hazard-reporter/public/tully-sidewalk.jpg` — seeded example evidence image
- `artifacts/civic-hazard-reporter/.replit-artifact/artifact.toml` — artifact routing and workflow metadata

## Architecture decisions

- Resident report submissions are saved through the shared API to PostgreSQL; the server generates the report number, summary title, default status, and creation timestamp.
- Saved Records reads the persisted reports from the API. Official review edits and the seeded example remain local demo state.
- AI output is represented as an editable draft; the official explicitly approves, requests more information, or rejects before the report proceeds.
- The seeded sidewalk obstruction keeps resident evidence and official review grounded in one concrete accessibility scenario.

## Product

- Residents can choose a hazard type, add a location and description, attach a photo, choose a contact preference, and receive a report number.
- Residents can view saved reports in reverse chronological order, including their stored status, summary title, contact preference, and ISO creation timestamp.
- City officials can inspect incoming complaints, compare the original evidence with the AI-assisted category and summary, add notes, and change status.
- The interface is responsive and includes clear navigation between resident and official views.

## User preferences

_No project-specific preferences recorded._

## Gotchas

- Only report intake records persist in PostgreSQL; reviewer edits, uploaded photo previews, and the seeded example are demo state and reset when the page reloads.

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
