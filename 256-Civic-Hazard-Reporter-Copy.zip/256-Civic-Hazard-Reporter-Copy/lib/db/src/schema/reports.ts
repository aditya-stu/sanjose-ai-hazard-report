import { pgTable, serial, text, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const reportsTable = pgTable("civic_hazard_reports", {
  id: serial("id").primaryKey(),
  issueType: text("issue_type").notNull(),
  location: text("location").notNull(),
  description: text("description").notNull(),
  contactPreference: text("contact_preference").notNull(),
  status: text("status").notNull().default("NEEDS REVIEW"),
  aiSummaryTitle: text("ai_summary_title").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

export const insertReportSchema = createInsertSchema(reportsTable).omit({
  id: true,
  status: true,
  createdAt: true,
});

export type InsertReport = z.infer<typeof insertReportSchema>;
export type Report = typeof reportsTable.$inferSelect;