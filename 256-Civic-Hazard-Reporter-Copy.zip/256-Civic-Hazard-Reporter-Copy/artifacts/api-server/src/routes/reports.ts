import { Router, type IRouter } from "express";
import { desc } from "drizzle-orm";
import {
  CreateReportBody,
  CreateReportResponse,
  ListReportsResponse,
} from "@workspace/api-zod";
import { db, reportsTable } from "@workspace/db";

const router: IRouter = Router();

function toReportRecord(report: typeof reportsTable.$inferSelect) {
  return {
    id: `SJ-${report.createdAt.getFullYear()}-${String(report.id).padStart(3, "0")}`,
    issueType: report.issueType,
    location: report.location,
    description: report.description,
    contactPreference: report.contactPreference,
    status: report.status,
    aiSummaryTitle: report.aiSummaryTitle,
    createdAt: report.createdAt,
  };
}

function createSummaryTitle(issueType: string, location: string): string {
  const landmark = location.split(",")[0]?.trim() || location.trim();
  return `${issueType.trim()} reported near ${landmark}`;
}

router.get("/reports", async (req, res): Promise<void> => {
  const reports = await db
    .select()
    .from(reportsTable)
    .orderBy(desc(reportsTable.createdAt), desc(reportsTable.id));

  res.json(ListReportsResponse.parse(reports.map(toReportRecord)));
});

router.post("/reports", async (req, res): Promise<void> => {
  const parsed = CreateReportBody.safeParse(req.body);
  if (!parsed.success) {
    req.log.warn({ errors: parsed.error.message }, "Invalid hazard report");
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const [report] = await db
    .insert(reportsTable)
    .values({
      ...parsed.data,
      aiSummaryTitle: createSummaryTitle(
        parsed.data.issueType,
        parsed.data.location,
      ),
    })
    .returning();

  res.status(201).json(CreateReportResponse.parse(toReportRecord(report)));
});

export default router;