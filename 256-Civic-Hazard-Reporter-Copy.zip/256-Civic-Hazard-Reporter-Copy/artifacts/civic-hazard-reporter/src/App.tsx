import { useEffect, useMemo, useState, type ChangeEvent, type FormEvent, type ReactNode } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import { getListReportsQueryKey, useCreateReport, useListReports, type Report } from '@workspace/api-client-react';
import { ArrowRight, BadgeCheck, Camera, Check, ChevronRight, Clock3, FileText, Flag, Image as ImageIcon, Info, LocateFixed, MapPin, Menu, MessageSquareText, PanelLeftClose, Pencil, RefreshCw, Save, ShieldCheck, Sparkles, Upload, X } from 'lucide-react';
import { Link, Route, Switch, useLocation, Router as WouterRouter } from 'wouter';
import NotFound from '@/pages/not-found';

const queryClient = new QueryClient();

type ComplaintStatus = 'Needs review' | 'Approved' | 'Needs info' | 'Rejected';

type Complaint = {
  id: string;
  issueType: string;
  title: string;
  description: string;
  location: string;
  submittedBy: string;
  submittedAt: string;
  status: ComplaintStatus;
  priority: 'High' | 'Medium' | 'Low';
  accessibilityImpact: boolean;
  photoPreview?: string;
  aiSummary: string;
  reviewerNote: string;
  contactPreference?: string;
};

type DraftSubmission = {
  issueType: string;
  location: string;
  description: string;
  photoPreview?: string;
  contactPreference: string;
};

function getErrorMessage(error: unknown) {
  if (error instanceof Error && error.message) return error.message;
  return 'We could not save this report. Check your connection and try again.';
}

const seedComplaint: Complaint = {
  id: 'SJ-2408-017',
  issueType: 'Obstructed sidewalk',
  title: 'Sidewalk blocked near Tully Road',
  description: 'A fallen branch and a construction cone are blocking most of the sidewalk on the north side of Tully Road, just west of King Road. There is only a narrow gap that is difficult to use with a mobility device.',
  location: 'Tully Road & King Road, San José',
  submittedBy: 'Marisol Alvarez',
  submittedAt: 'Today, 9:18 AM',
  status: 'Needs review',
  priority: 'High',
  accessibilityImpact: true,
  photoPreview: '/tully-sidewalk.jpg',
  aiSummary: 'Obstructed pedestrian path near Tully Road, with a likely accessibility impact. Route appears partially blocked by a fallen branch and a cone.',
  reviewerNote: '',
  contactPreference: 'Email',
};

function AppLogo({ compact = false }: { compact?: boolean }) {
  return (
    <Link href="/" className="focus-ring flex items-center gap-3" data-testid="link-home-logo">
      <span className="relative flex size-9 shrink-0 items-center justify-center rounded-[11px] bg-primary text-primary-foreground shadow-[3px_3px_0_hsl(var(--accent))]">
        <span className="absolute left-[9px] top-[9px] size-2 rounded-full bg-accent" />
        <span className="absolute bottom-[9px] right-[9px] size-2 rounded-full bg-primary-foreground" />
        <span className="absolute left-[11px] top-[16px] h-[2px] w-[15px] rotate-45 bg-primary-foreground" />
      </span>
      {!compact && (
        <span className="leading-none">
          <span className="block font-display text-[17px] font-semibold tracking-[-0.02em] text-foreground">Civic Hazard</span>
          <span className="mt-1 block font-mono text-[9px] font-bold uppercase tracking-[0.18em] text-muted-foreground">Reporter / San José</span>
        </span>
      )}
    </Link>
  );
}

function AppShell({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  const [mobileOpen, setMobileOpen] = useState(false);
  const reviewActive = location === '/review';
  const recordsActive = location === '/records';

  return (
    <div className="paper-grain min-h-[100dvh] bg-background">
      <header className="relative z-20 border-b border-border/80 bg-background/95 backdrop-blur">
        <div className="mx-auto flex h-[76px] max-w-[1320px] items-center justify-between px-5 sm:px-8 lg:px-12">
          <AppLogo />
          <nav className="hidden items-center gap-1 md:flex" aria-label="Primary navigation">
             <Link href="/" className={`focus-ring rounded-full px-4 py-2.5 text-sm font-semibold transition-colors ${!reviewActive && !recordsActive ? 'bg-primary/10 text-primary' : 'text-muted-foreground hover:bg-muted hover:text-foreground'}`} data-testid="link-resident-view">
              Report a hazard
            </Link>
            <Link href="/review" className={`focus-ring rounded-full px-4 py-2.5 text-sm font-semibold transition-colors ${reviewActive ? 'bg-primary/10 text-primary' : 'text-muted-foreground hover:bg-muted hover:text-foreground'}`} data-testid="link-official-view">
              Official review
              <span className="ml-2 inline-flex size-5 items-center justify-center rounded-full bg-accent font-mono text-[10px] font-bold text-accent-foreground">1</span>
            </Link>
             <Link href="/records" className={`focus-ring rounded-full px-4 py-2.5 text-sm font-semibold transition-colors ${recordsActive ? 'bg-primary/10 text-primary' : 'text-muted-foreground hover:bg-muted hover:text-foreground'}`} data-testid="link-records-view">
               Saved records
             </Link>
          </nav>
          <button className="focus-ring rounded-lg p-2 text-foreground md:hidden" onClick={() => setMobileOpen((value) => !value)} aria-label="Open navigation" data-testid="button-toggle-navigation">
            {mobileOpen ? <X size={22} /> : <Menu size={22} />}
          </button>
        </div>
        {mobileOpen && (
          <nav className="border-t border-border/80 bg-card px-5 py-3 md:hidden" aria-label="Mobile navigation">
            <Link href="/" onClick={() => setMobileOpen(false)} className="flex items-center justify-between border-b border-border py-4 text-sm font-semibold" data-testid="link-mobile-resident-view">
              Report a hazard <ChevronRight size={17} className="text-muted-foreground" />
            </Link>
            <Link href="/review" onClick={() => setMobileOpen(false)} className="flex items-center justify-between py-4 text-sm font-semibold" data-testid="link-mobile-official-view">
              Official review <span className="rounded-full bg-accent px-2 py-1 font-mono text-[10px] text-accent-foreground">1 open</span>
            </Link>
            <Link href="/records" onClick={() => setMobileOpen(false)} className="flex items-center justify-between border-t border-border py-4 text-sm font-semibold" data-testid="link-mobile-records-view">
              Saved records <ChevronRight size={17} className="text-muted-foreground" />
            </Link>
          </nav>
        )}
      </header>
      {children}
      <footer className="border-t border-border/80 bg-card/60">
        <div className="mx-auto flex max-w-[1320px] flex-col gap-3 px-5 py-8 text-xs text-muted-foreground sm:px-8 lg:flex-row lg:items-center lg:justify-between lg:px-12">
          <p className="font-mono uppercase tracking-[0.14em]">A demo for clearer city maintenance</p>
          <p>San José · Built for neighbors, reviewed by people</p>
        </div>
      </footer>
    </div>
  );
}

function FieldLabel({ children, hint }: { children: ReactNode; hint?: string }) {
  return (
    <div className="mb-2 flex items-baseline justify-between gap-3">
      <label className="text-sm font-bold text-foreground">{children}</label>
      {hint && <span className="text-xs text-muted-foreground">{hint}</span>}
    </div>
  );
}

function StatusPill({ status }: { status: ComplaintStatus }) {
  const styles: Record<ComplaintStatus, string> = {
    'Needs review': 'border-accent/50 bg-accent/20 text-accent-foreground',
    Approved: 'border-emerald-600/20 bg-emerald-600/10 text-emerald-700',
    'Needs info': 'border-primary/20 bg-primary/10 text-primary',
    Rejected: 'border-destructive/20 bg-destructive/10 text-destructive',
  };
  return <span className={`inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 font-mono text-[10px] font-bold uppercase tracking-[0.12em] ${styles[status]}`} data-testid={`status-complaint-${status.toLowerCase().replaceAll(' ', '-')}`}><span className="size-1.5 rounded-full bg-current" />{status}</span>;
}

function ResidentPage({ complaints, onSubmit }: { complaints: Complaint[]; onSubmit: (draft: DraftSubmission) => Promise<Report> }) {
  const [issueType, setIssueType] = useState('Obstructed sidewalk');
  const [location, setLocation] = useState('');
  const [description, setDescription] = useState('');
  const [contactPreference, setContactPreference] = useState('Email');
  const [photoPreview, setPhotoPreview] = useState<string | undefined>();
  const [photoName, setPhotoName] = useState('');
  const [submitted, setSubmitted] = useState<Complaint | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState('');
  const recent = complaints[0] ?? seedComplaint;

  const onPhotoChange = (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;
    setPhotoName(file.name);
    setPhotoPreview(URL.createObjectURL(file));
  };

  const handleSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!location.trim() || !description.trim()) return;
    setIsSubmitting(true);
    setSubmitError('');
    void onSubmit({ issueType, location: location.trim(), description: description.trim(), photoPreview, contactPreference })
      .then((report) => {
        const next: Complaint = {
          id: report.id,
          issueType: report.issueType,
          title: report.aiSummaryTitle,
          description: report.description,
          location: report.location,
          submittedBy: 'San José resident',
          submittedAt: report.createdAt,
          status: 'Needs review',
          priority: report.issueType === 'Obstructed sidewalk' ? 'High' : 'Medium',
          accessibilityImpact: report.issueType === 'Obstructed sidewalk',
          photoPreview,
          aiSummary: report.aiSummaryTitle,
          reviewerNote: '',
          contactPreference: report.contactPreference,
        };
        setSubmitted(next);
        setLocation('');
        setDescription('');
        setPhotoPreview(undefined);
        setPhotoName('');
      })
      .catch((error: unknown) => setSubmitError(`${getErrorMessage(error)} Nothing was submitted.`))
      .finally(() => setIsSubmitting(false));
  };

  return (
    <main>
      <section className="civic-grid overflow-hidden border-b border-border/80">
        <div className="mx-auto grid max-w-[1320px] gap-10 px-5 pb-14 pt-12 sm:px-8 sm:pt-16 lg:grid-cols-[1.05fr_.95fr] lg:gap-20 lg:px-12 lg:pb-20 lg:pt-20">
          <div className="rise-in self-center">
            <div className="mb-5 flex items-center gap-2 font-mono text-[10px] font-bold uppercase tracking-[0.19em] text-primary">
              <span className="h-px w-8 bg-accent" /> San José public right-of-way
            </div>
            <h1 className="max-w-[650px] font-display text-[clamp(3.3rem,7vw,6.5rem)] font-semibold leading-[.92] tracking-[-0.055em] text-foreground">
              Make the <span className="text-primary">next step</span> safer.
            </h1>
            <p className="mt-7 max-w-[560px] text-lg leading-8 text-muted-foreground">
              See a blocked sidewalk, unsafe crossing, or damaged signal? Tell the city what is happening on the ground. A clear report helps the right team act sooner.
            </p>
            <div className="mt-8 flex flex-wrap items-center gap-x-7 gap-y-3 text-sm font-semibold text-foreground">
              <span className="flex items-center gap-2"><ShieldCheck size={17} className="text-primary" /> No account required</span>
              <span className="flex items-center gap-2"><Clock3 size={17} className="text-primary" /> Takes about 2 minutes</span>
            </div>
          </div>
          <div className="rise-in rise-in-delay-1 relative min-h-[310px] overflow-hidden rounded-[28px] border border-primary/20 bg-primary shadow-[12px_12px_0_hsl(var(--accent)/.8)] sm:min-h-[370px]">
            <img src="/tully-sidewalk.jpg" alt="A branch and traffic cone partially block a sidewalk near Tully Road" className="absolute inset-0 size-full object-cover opacity-70 mix-blend-luminosity" data-testid="img-hero-sidewalk" />
            <div className="absolute inset-0 bg-gradient-to-t from-primary via-primary/35 to-transparent" />
            <div className="absolute inset-x-0 bottom-0 p-7 sm:p-9">
              <div className="mb-5 flex size-11 items-center justify-center rounded-2xl bg-accent text-accent-foreground"><LocateFixed size={21} /></div>
              <p className="max-w-[360px] font-display text-2xl font-semibold leading-tight text-primary-foreground">Your view of the street is useful evidence.</p>
              <p className="mt-3 max-w-[390px] text-sm leading-6 text-primary-foreground/75">Add a photo if it is safe to do so. The reviewer sees the original context before anything is approved.</p>
            </div>
            <div className="absolute right-5 top-5 rounded-full border border-primary-foreground/25 bg-primary/40 px-3 py-1.5 font-mono text-[10px] uppercase tracking-[.15em] text-primary-foreground">Field note 01</div>
          </div>
        </div>
      </section>

      <section className="mx-auto grid max-w-[1320px] gap-8 px-5 py-12 sm:px-8 lg:grid-cols-[minmax(0,1fr)_340px] lg:gap-16 lg:px-12 lg:py-20">
        <div className="rise-in rise-in-delay-2">
          <div className="mb-8 flex items-end justify-between gap-6">
            <div>
              <p className="font-mono text-[10px] font-bold uppercase tracking-[.18em] text-primary">01 / New report</p>
              <h2 className="mt-3 font-display text-3xl font-semibold tracking-[-.04em] sm:text-4xl">What needs attention?</h2>
            </div>
            <span className="hidden items-center gap-2 text-xs text-muted-foreground sm:flex"><span className="size-2 rounded-full bg-accent" /> Required fields marked by context</span>
          </div>

          {submitted && (
            <div className="mb-8 flex gap-4 rounded-2xl border border-emerald-700/20 bg-emerald-700/[.07] p-5" role="status" data-testid="status-report-submitted">
              <div className="flex size-10 shrink-0 items-center justify-center rounded-full bg-emerald-700 text-card"><Check size={20} strokeWidth={3} /></div>
              <div className="min-w-0">
                <p className="font-bold text-foreground">Report received. Thank you for looking out.</p>
                <p className="mt-1 text-sm leading-6 text-muted-foreground">Your report number is <strong className="font-mono text-foreground" data-testid="text-report-number">{submitted.id}</strong>. Keep it handy if you contact the city.</p>
                <button onClick={() => setSubmitted(null)} className="mt-3 text-xs font-bold text-primary underline decoration-primary/30 underline-offset-4 hover:decoration-primary" data-testid="button-dismiss-confirmation">Submit another report</button>
              </div>
            </div>
          )}
          {submitError && (
            <div className="mb-8 flex gap-4 rounded-2xl border border-destructive/25 bg-destructive/[.07] p-5" role="alert" data-testid="status-report-error">
              <div className="flex size-10 shrink-0 items-center justify-center rounded-full bg-destructive text-destructive-foreground"><X size={19} strokeWidth={3} /></div>
              <div className="min-w-0">
                <p className="font-bold text-foreground">Report not saved</p>
                <p className="mt-1 text-sm leading-6 text-muted-foreground">{submitError}</p>
                <button onClick={() => setSubmitError('')} className="mt-3 text-xs font-bold text-primary underline decoration-primary/30 underline-offset-4 hover:decoration-primary" data-testid="button-dismiss-report-error">Dismiss and try again</button>
              </div>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-7 rounded-[24px] border border-border bg-card p-5 shadow-[0_12px_40px_hsl(var(--primary)/.06)] sm:p-8" data-testid="form-new-report">
            <div>
              <FieldLabel>Issue type</FieldLabel>
              <div className="grid grid-cols-1 gap-2 sm:grid-cols-3">
                {['Obstructed sidewalk', 'Crossing or signal', 'Road or surface'].map((option) => (
                  <button key={option} type="button" onClick={() => setIssueType(option)} className={`focus-ring pressable rounded-xl border px-3 py-3 text-left text-sm font-semibold ${issueType === option ? 'border-primary bg-primary/10 text-primary' : 'border-border bg-background text-muted-foreground hover:border-primary/40 hover:text-foreground'}`} data-testid={`button-issue-type-${option.toLowerCase().replaceAll(' ', '-')}`}>
                    <span className={`mb-3 block size-2 rounded-full ${issueType === option ? 'bg-accent' : 'bg-border'}`} />{option}
                  </button>
                ))}
              </div>
            </div>
            <div>
              <FieldLabel hint="Street, intersection, or landmark">Where is it?</FieldLabel>
              <div className="relative">
                <MapPin size={18} className="pointer-events-none absolute left-4 top-1/2 -translate-y-1/2 text-primary" />
                <input value={location} onChange={(event) => setLocation(event.target.value)} placeholder="e.g. Tully Road & King Road" className="focus-ring h-13 w-full rounded-xl border border-input bg-background pl-11 pr-4 text-sm text-foreground outline-none transition-colors placeholder:text-muted-foreground/70 focus:border-primary" data-testid="input-report-location" required />
              </div>
            </div>
            <div>
              <FieldLabel hint="What would help someone find it?">Describe what you see</FieldLabel>
              <textarea value={description} onChange={(event) => setDescription(event.target.value)} placeholder="Include what is blocked or damaged, which side of the street, and how it affects people moving through the area." className="focus-ring min-h-32 w-full resize-y rounded-xl border border-input bg-background p-4 text-sm leading-6 text-foreground outline-none transition-colors placeholder:text-muted-foreground/70 focus:border-primary" data-testid="input-report-description" required />
            </div>
            <div>
              <FieldLabel hint="Optional">Add a photo</FieldLabel>
              <label className="focus-ring group flex cursor-pointer items-center gap-4 rounded-xl border border-dashed border-primary/30 bg-primary/[.035] p-4 transition-colors hover:border-primary/60 hover:bg-primary/[.07]" data-testid="input-report-photo-label">
                {photoPreview ? (
                  <img src={photoPreview} alt="Selected report preview" className="size-16 rounded-lg object-cover" data-testid="img-upload-preview" />
                ) : (
                  <span className="flex size-16 shrink-0 items-center justify-center rounded-lg bg-primary/10 text-primary"><Camera size={23} /></span>
                )}
                <span className="min-w-0">
                  <span className="block text-sm font-bold text-foreground">{photoName || 'Choose a photo from your device'}</span>
                  <span className="mt-1 block text-xs leading-5 text-muted-foreground">{photoName ? 'Ready to attach to this report.' : 'Only add one if it is safe. JPG or PNG, up to 10 MB.'}</span>
                </span>
                <Upload size={17} className="ml-auto shrink-0 text-primary transition-transform group-hover:-translate-y-0.5" />
                <input type="file" accept="image/*" onChange={onPhotoChange} className="sr-only" data-testid="input-report-photo" />
              </label>
            </div>
            <div>
              <FieldLabel hint="Optional">How should we contact you?</FieldLabel>
              <div className="flex flex-wrap gap-2">
                {['Email', 'Phone', 'No follow-up'].map((option) => (
                  <label key={option} className={`focus-within:ring-2 focus-within:ring-accent/70 flex cursor-pointer items-center gap-2 rounded-full border px-4 py-2.5 text-sm font-semibold transition-colors ${contactPreference === option ? 'border-primary bg-primary text-primary-foreground' : 'border-border text-muted-foreground hover:border-primary/40'}`}>
                    <input type="radio" name="contact" value={option} checked={contactPreference === option} onChange={() => setContactPreference(option)} className="sr-only" data-testid={`input-contact-${option.toLowerCase().replaceAll(' ', '-')}`} />
                    {option}
                  </label>
                ))}
              </div>
            </div>
            <div className="flex flex-col gap-4 border-t border-border pt-6 sm:flex-row sm:items-center sm:justify-between">
              <p className="flex max-w-sm gap-2 text-xs leading-5 text-muted-foreground"><Info size={15} className="mt-0.5 shrink-0 text-primary" /> We use your details only to follow up on this report. You can always choose no follow-up.</p>
              <button type="submit" disabled={isSubmitting} className="pressable focus-ring flex h-12 shrink-0 items-center justify-center gap-2 rounded-xl bg-primary px-6 text-sm font-bold text-primary-foreground shadow-[4px_4px_0_hsl(var(--accent))] transition-opacity hover:opacity-90 disabled:cursor-wait disabled:opacity-70" data-testid="button-submit-report">
                {isSubmitting ? 'Sending report…' : 'Send report'} <ArrowRight size={17} />
              </button>
            </div>
          </form>
        </div>

        <aside className="rise-in rise-in-delay-3 lg:pt-[72px]">
          <div className="sticky top-6 overflow-hidden rounded-[22px] border border-border bg-card">
            <div className="border-b border-border bg-primary px-5 py-5 text-primary-foreground">
              <div className="flex items-center justify-between">
                <span className="font-mono text-[10px] font-bold uppercase tracking-[.16em] text-primary-foreground/65">02 / Recent report</span>
                <FileText size={17} className="text-accent" />
              </div>
              <p className="mt-4 font-display text-xl font-semibold leading-tight">{recent.title}</p>
              <div className="mt-4"><StatusPill status={recent.status} /></div>
            </div>
            <div className="space-y-5 p-5">
              {recent.photoPreview && <img src={recent.photoPreview} alt="Recent report photo" className="h-36 w-full rounded-xl object-cover" data-testid="img-recent-report" />}
              <div className="space-y-3 text-sm">
                <p className="flex gap-3"><MapPin size={16} className="mt-0.5 shrink-0 text-primary" /><span data-testid="text-recent-location">{recent.location}</span></p>
                <p className="flex gap-3"><Clock3 size={16} className="mt-0.5 shrink-0 text-primary" /><span>{recent.submittedAt}</span></p>
              </div>
              <div className="border-t border-border pt-4">
                <p className="font-mono text-[10px] uppercase tracking-[.13em] text-muted-foreground">What happens next</p>
                <p className="mt-2 text-sm leading-6 text-muted-foreground">A city team reviews the details and routes it to the right crew. A person checks the AI-assisted summary before anything moves forward.</p>
              </div>
              <Link href="/review" className="focus-ring pressable flex items-center justify-between rounded-xl bg-secondary px-4 py-3 text-xs font-bold text-secondary-foreground hover:bg-primary hover:text-primary-foreground" data-testid="link-see-official-review">
                See the official review <ArrowRight size={15} />
              </Link>
            </div>
          </div>
        </aside>
      </section>
    </main>
  );
}

function ReviewPage({ complaints, updateComplaint }: { complaints: Complaint[]; updateComplaint: (id: string, changes: Partial<Complaint>) => void }) {
  const [selectedId, setSelectedId] = useState(complaints[0]?.id ?? seedComplaint.id);
  const [category, setCategory] = useState('');
  const [summary, setSummary] = useState('');
  const [reviewerNote, setReviewerNote] = useState('');
  const [saved, setSaved] = useState(false);
  const selected = complaints.find((complaint) => complaint.id === selectedId) ?? complaints[0] ?? seedComplaint;

  useEffect(() => {
    setCategory(selected.issueType);
    setSummary(selected.aiSummary);
    setReviewerNote(selected.reviewerNote);
    setSaved(false);
  }, [selected.id]);

  const saveDraft = () => {
    updateComplaint(selected.id, { issueType: category, aiSummary: summary, reviewerNote });
    setSaved(true);
    window.setTimeout(() => setSaved(false), 2200);
  };

  const moveTo = (status: ComplaintStatus) => {
    updateComplaint(selected.id, { issueType: category, aiSummary: summary, reviewerNote, status });
    setSaved(true);
    window.setTimeout(() => setSaved(false), 2200);
  };

  const openCount = complaints.filter((complaint) => complaint.status === 'Needs review' || complaint.status === 'Needs info').length;

  return (
    <main className="bg-[#eef0ec]">
      <div className="mx-auto max-w-[1440px] px-4 py-6 sm:px-7 lg:px-10 lg:py-10">
        <div className="mb-8 flex flex-col justify-between gap-5 md:flex-row md:items-end">
          <div>
            <div className="mb-3 flex items-center gap-2 font-mono text-[10px] font-bold uppercase tracking-[.18em] text-primary"><PanelLeftClose size={14} /> Internal workspace / Public works</div>
            <h1 className="font-display text-4xl font-semibold tracking-[-.05em] text-foreground sm:text-5xl">Review queue</h1>
            <p className="mt-3 max-w-xl text-sm leading-6 text-muted-foreground">Verify the story before it becomes a work order. The resident’s original words and photo stay visible beside the AI-assisted draft.</p>
          </div>
          <div className="flex items-center gap-3 rounded-2xl border border-border bg-card px-4 py-3">
            <span className="flex size-9 items-center justify-center rounded-xl bg-accent text-accent-foreground"><Flag size={17} /></span>
            <div><p className="font-mono text-[10px] uppercase tracking-[.13em] text-muted-foreground">Open queue</p><p className="font-display text-xl font-semibold" data-testid="text-open-queue-count">{openCount.toString().padStart(2, '0')}</p></div>
          </div>
        </div>

        <div className="grid gap-5 lg:grid-cols-[285px_minmax(0,1fr)]">
          <aside className="h-fit rounded-[20px] border border-border bg-card p-3">
            <div className="flex items-center justify-between px-3 py-3"><span className="font-mono text-[10px] font-bold uppercase tracking-[.16em] text-muted-foreground">Incoming reports</span><span className="rounded-full bg-muted px-2 py-1 font-mono text-[10px] text-muted-foreground">{complaints.length}</span></div>
            <div className="space-y-2">
              {complaints.map((complaint) => (
                <button key={complaint.id} onClick={() => setSelectedId(complaint.id)} className={`focus-ring pressable w-full rounded-xl border p-3 text-left ${selected.id === complaint.id ? 'border-primary bg-primary/[.07]' : 'border-transparent hover:border-border hover:bg-muted/50'}`} data-testid={`button-select-complaint-${complaint.id}`}>
                  <div className="flex items-center justify-between gap-2"><span className="font-mono text-[10px] font-bold text-muted-foreground">{complaint.id}</span><span className={`size-2 rounded-full ${complaint.status === 'Needs review' ? 'bg-accent' : complaint.status === 'Approved' ? 'bg-emerald-600' : complaint.status === 'Rejected' ? 'bg-destructive' : 'bg-primary'}`} /></div>
                  <p className="mt-2 line-clamp-2 text-sm font-bold leading-5 text-foreground">{complaint.title}</p>
                  <p className="mt-2 truncate text-xs text-muted-foreground">{complaint.location}</p>
                </button>
              ))}
            </div>
            <div className="mt-4 border-t border-border px-3 pt-4"><p className="flex gap-2 text-xs leading-5 text-muted-foreground"><ShieldCheck size={15} className="mt-0.5 shrink-0 text-primary" /> AI suggestions are drafts. You have final say.</p></div>
          </aside>

          <section className="min-w-0 rounded-[20px] border border-border bg-card">
            <div className="flex flex-col gap-4 border-b border-border px-5 py-5 sm:flex-row sm:items-start sm:justify-between sm:px-7">
              <div><div className="flex flex-wrap items-center gap-3"><span className="font-mono text-xs font-bold text-muted-foreground" data-testid="text-selected-complaint-id">{selected.id}</span><StatusPill status={selected.status} /></div><h2 className="mt-3 font-display text-2xl font-semibold tracking-[-.035em] text-foreground">{selected.title}</h2></div>
              <div className="flex items-center gap-2 rounded-xl bg-muted px-3 py-2 text-xs text-muted-foreground"><Clock3 size={15} /> Received {selected.submittedAt}</div>
            </div>
            <div className="grid xl:grid-cols-[.95fr_1.05fr]">
              <div className="border-b border-border p-5 sm:p-7 xl:border-b-0 xl:border-r">
                <div className="mb-5 flex items-center justify-between"><h3 className="font-mono text-[10px] font-bold uppercase tracking-[.16em] text-primary">Resident submission</h3><span className="flex items-center gap-1.5 text-xs text-muted-foreground"><BadgeCheck size={14} className="text-primary" /> Original context</span></div>
                {selected.photoPreview ? <div className="group relative overflow-hidden rounded-2xl bg-muted"><img src={selected.photoPreview} alt="Resident submitted street condition" className="aspect-[4/3] w-full object-cover" data-testid="img-review-original-photo" /><div className="absolute bottom-3 left-3 rounded-full bg-foreground/80 px-3 py-1.5 font-mono text-[10px] uppercase tracking-[.12em] text-background">Photo attached by resident</div></div> : <div className="flex aspect-[4/3] items-center justify-center rounded-2xl bg-muted text-muted-foreground"><ImageIcon size={28} /></div>}
                <div className="mt-6 space-y-5">
                  <div><p className="mb-2 font-mono text-[10px] font-bold uppercase tracking-[.13em] text-muted-foreground">Location</p><p className="flex gap-2 text-sm leading-6 text-foreground" data-testid="text-review-location"><MapPin size={16} className="mt-1 shrink-0 text-primary" />{selected.location}</p></div>
                  <div><p className="mb-2 font-mono text-[10px] font-bold uppercase tracking-[.13em] text-muted-foreground">Original description</p><p className="text-sm leading-7 text-foreground" data-testid="text-review-original-description">“{selected.description}”</p></div>
                  <div className="flex flex-wrap gap-2"><span className="rounded-full border border-accent/50 bg-accent/15 px-3 py-1.5 text-xs font-bold text-accent-foreground">{selected.priority} priority</span>{selected.accessibilityImpact && <span className="rounded-full border border-primary/20 bg-primary/10 px-3 py-1.5 text-xs font-bold text-primary">Accessibility impact</span>}</div>
                </div>
              </div>
              <div className="p-5 sm:p-7">
                <div className="mb-5 flex items-center justify-between"><div><h3 className="font-mono text-[10px] font-bold uppercase tracking-[.16em] text-primary">AI-assisted draft</h3><p className="mt-2 text-xs text-muted-foreground">Edit anything that does not match the evidence.</p></div><Sparkles size={20} className="text-accent-foreground" /></div>
                <div className="space-y-6">
                  <div><FieldLabel>Category</FieldLabel><div className="relative"><select value={category} onChange={(event) => setCategory(event.target.value)} className="focus-ring h-12 w-full appearance-none rounded-xl border border-input bg-background px-4 text-sm font-semibold text-foreground outline-none focus:border-primary" data-testid="select-review-category"><option>Obstructed sidewalk</option><option>Crossing or signal</option><option>Road or surface</option><option>Street lighting</option><option>Other public right-of-way</option></select><ChevronRight size={17} className="pointer-events-none absolute right-4 top-1/2 -translate-y-1/2 rotate-90 text-primary" /></div></div>
                  <div><FieldLabel>Suggested summary</FieldLabel><textarea value={summary} onChange={(event) => setSummary(event.target.value)} className="focus-ring min-h-32 w-full resize-y rounded-xl border border-input bg-background p-4 text-sm leading-6 text-foreground outline-none focus:border-primary" data-testid="input-review-summary" /></div>
                  <div className="rounded-xl border border-primary/20 bg-primary/[.045] p-4"><p className="flex items-center gap-2 font-mono text-[10px] font-bold uppercase tracking-[.13em] text-primary"><MessageSquareText size={14} /> Reviewer note</p><textarea value={reviewerNote} onChange={(event) => setReviewerNote(event.target.value)} placeholder="Add routing context or a note for the crew…" className="focus-ring mt-3 min-h-20 w-full resize-y bg-transparent text-sm leading-6 text-foreground outline-none placeholder:text-muted-foreground/70" data-testid="input-reviewer-note" /></div>
                  <div className="flex flex-col gap-3 border-t border-border pt-5 sm:flex-row sm:items-center sm:justify-between"><button onClick={saveDraft} className="focus-ring pressable flex items-center justify-center gap-2 rounded-xl border border-border px-4 py-3 text-sm font-bold text-foreground hover:bg-muted" data-testid="button-save-draft"><Pencil size={15} /> {saved ? 'Saved to queue' : 'Save edits'}</button><div className="flex flex-wrap gap-2 sm:justify-end"><button onClick={() => moveTo('Rejected')} className="focus-ring pressable rounded-xl border border-destructive/25 px-3 py-3 text-xs font-bold text-destructive hover:bg-destructive/10" data-testid="button-reject-report">Reject</button><button onClick={() => moveTo('Needs info')} className="focus-ring pressable rounded-xl border border-primary/25 px-3 py-3 text-xs font-bold text-primary hover:bg-primary/10" data-testid="button-request-info">Need more info</button><button onClick={() => moveTo('Approved')} className="focus-ring pressable flex items-center gap-2 rounded-xl bg-primary px-4 py-3 text-xs font-bold text-primary-foreground shadow-[3px_3px_0_hsl(var(--accent))] hover:opacity-90" data-testid="button-approve-report"><Check size={15} /> Approve</button></div></div>
                </div>
              </div>
            </div>
            {saved && <div className="flex items-center gap-2 border-t border-border bg-emerald-700/[.06] px-5 py-3 text-xs font-semibold text-emerald-800 sm:px-7" role="status" data-testid="status-review-saved"><Check size={15} /> Queue updated. The latest edits are visible to the next team.</div>}
          </section>
        </div>
      </div>
    </main>
  );
}

function RecordsSkeleton() {
  return (
    <div className="space-y-4" aria-label="Loading saved records" data-testid="state-records-loading">
      {[1, 2, 3].map((item) => (
        <div key={item} className="animate-pulse rounded-[22px] border border-border bg-card p-5 sm:p-6">
          <div className="flex flex-wrap justify-between gap-4"><div className="h-3 w-28 rounded bg-muted" /><div className="h-6 w-24 rounded-full bg-muted" /></div>
          <div className="mt-5 h-6 w-2/3 rounded bg-muted" />
          <div className="mt-4 h-4 w-full rounded bg-muted" />
          <div className="mt-2 h-4 w-4/5 rounded bg-muted" />
          <div className="mt-6 h-3 w-1/3 rounded bg-muted" />
        </div>
      ))}
    </div>
  );
}

function RecordsPage() {
  const reportsQuery = useListReports({
    query: {
      queryKey: getListReportsQueryKey(),
      refetchOnMount: 'always',
      refetchOnWindowFocus: true,
      staleTime: 0,
    },
  });
  const reports = useMemo(
    () =>
      [...(reportsQuery.data ?? [])].sort(
        (left, right) =>
          new Date(right.createdAt).getTime() - new Date(left.createdAt).getTime(),
      ),
    [reportsQuery.data],
  );

  return (
    <main className="civic-grid min-h-[70dvh] border-b border-border/80">
      <div className="mx-auto max-w-[1120px] px-5 py-12 sm:px-8 sm:py-16 lg:px-12 lg:py-20">
        <div className="rise-in mb-10 flex flex-col justify-between gap-6 border-b border-border/80 pb-8 sm:flex-row sm:items-end">
          <div>
            <div className="mb-4 flex items-center gap-2 font-mono text-[10px] font-bold uppercase tracking-[.18em] text-primary"><span className="h-px w-8 bg-accent" /> Community record</div>
            <h1 className="font-display text-4xl font-semibold tracking-[-.055em] text-foreground sm:text-6xl">Saved records</h1>
            <p className="mt-4 max-w-2xl text-base leading-7 text-muted-foreground">A shared view of reports saved for city review. Records appear newest first and keep the resident’s original description alongside the assisted title.</p>
            {reportsQuery.isSuccess && (
              <p className="mt-3 font-mono text-[10px] font-bold uppercase tracking-[.15em] text-primary" data-testid="text-record-count">
                {reports.length} records loaded from the database
              </p>
            )}
          </div>
          <Link href="/" className="focus-ring pressable inline-flex shrink-0 items-center justify-center gap-2 rounded-xl bg-primary px-4 py-3 text-sm font-bold text-primary-foreground shadow-[3px_3px_0_hsl(var(--accent))]" data-testid="link-records-new-report">
            <FileText size={16} /> New report
          </Link>
        </div>

        {reportsQuery.isLoading && <RecordsSkeleton />}
        {reportsQuery.isError && (
          <div className="rounded-[22px] border border-destructive/25 bg-card p-7 text-center" role="alert" data-testid="state-records-error">
            <div className="mx-auto flex size-12 items-center justify-center rounded-2xl bg-destructive/10 text-destructive"><RefreshCw size={21} /></div>
            <h2 className="mt-4 font-display text-2xl font-semibold tracking-[-.03em]">Records are unavailable</h2>
            <p className="mx-auto mt-2 max-w-md text-sm leading-6 text-muted-foreground">The saved record service did not respond. Check your connection, then try loading the records again.</p>
            <button onClick={() => void reportsQuery.refetch()} className="focus-ring pressable mt-5 inline-flex items-center gap-2 rounded-xl bg-primary px-4 py-3 text-sm font-bold text-primary-foreground" data-testid="button-retry-records">
              <RefreshCw size={15} /> Try again
            </button>
          </div>
        )}
        {!reportsQuery.isLoading && !reportsQuery.isError && reports.length === 0 && (
          <div className="rounded-[22px] border border-dashed border-primary/30 bg-card/80 p-10 text-center sm:p-16" data-testid="state-records-empty">
            <div className="mx-auto flex size-14 items-center justify-center rounded-2xl bg-primary/10 text-primary"><Save size={24} /></div>
            <h2 className="mt-5 font-display text-2xl font-semibold tracking-[-.03em]">No saved reports yet</h2>
            <p className="mx-auto mt-2 max-w-md text-sm leading-6 text-muted-foreground">When a resident sends a report, it will stay here for the community and the city team to review.</p>
            <Link href="/" className="focus-ring pressable mt-6 inline-flex items-center gap-2 rounded-xl border border-primary/25 px-4 py-3 text-sm font-bold text-primary hover:bg-primary/10" data-testid="link-empty-records-report">
              Report a hazard <ArrowRight size={15} />
            </Link>
          </div>
        )}
        {!reportsQuery.isLoading && !reportsQuery.isError && reports.length > 0 && (
          <div className="space-y-4" data-testid="list-saved-records">
            {reports.map((report) => (
              <article key={report.id} className="rise-in rounded-[22px] border border-border bg-card p-5 shadow-[0_10px_30px_hsl(var(--primary)/.045)] transition-transform hover:-translate-y-0.5 sm:p-6" data-testid={`card-saved-record-${report.id}`}>
                <div className="flex flex-col gap-5 lg:flex-row lg:items-start lg:justify-between">
                  <div className="min-w-0">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="font-mono text-[10px] font-bold uppercase tracking-[.13em] text-muted-foreground" data-testid={`text-record-id-${report.id}`}>{report.id}</span>
                      <span className="rounded-full border border-accent/50 bg-accent/20 px-2.5 py-1 font-mono text-[10px] font-bold uppercase tracking-[.1em] text-accent-foreground" data-testid={`status-record-${report.id}`}>{report.status}</span>
                    </div>
                    <h2 className="mt-4 font-display text-2xl font-semibold leading-tight tracking-[-.035em] text-foreground" data-testid={`text-record-summary-${report.id}`}>{report.aiSummaryTitle}</h2>
                    <p className="mt-3 flex gap-2 text-sm font-semibold text-foreground" data-testid={`text-record-location-${report.id}`}><MapPin size={16} className="mt-0.5 shrink-0 text-primary" />{report.location}</p>
                  </div>
                  <div className="shrink-0 rounded-xl bg-muted px-3 py-2 text-xs text-muted-foreground lg:text-right">
                    <p className="font-mono text-[9px] font-bold uppercase tracking-[.14em]">Saved at</p>
                    <time className="mt-1 block font-mono text-[11px] text-foreground" dateTime={report.createdAt} data-testid={`text-record-created-at-${report.id}`}>{report.createdAt}</time>
                  </div>
                </div>
                <div className="mt-6 grid gap-5 border-t border-border pt-5 md:grid-cols-[1fr_auto]">
                  <div>
                    <p className="mb-2 font-mono text-[10px] font-bold uppercase tracking-[.13em] text-muted-foreground">Resident description</p>
                    <p className="text-sm leading-7 text-foreground" data-testid={`text-record-description-${report.id}`}>{report.description}</p>
                  </div>
                  <div className="flex flex-wrap content-start gap-2 md:max-w-[240px] md:justify-end">
                    <span className="rounded-full border border-primary/20 bg-primary/10 px-3 py-1.5 text-xs font-bold text-primary" data-testid={`text-record-issue-type-${report.id}`}>{report.issueType}</span>
                    <span className="rounded-full border border-border bg-background px-3 py-1.5 text-xs font-semibold text-muted-foreground" data-testid={`text-record-contact-${report.id}`}>Follow-up: {report.contactPreference}</span>
                  </div>
                </div>
              </article>
            ))}
          </div>
        )}
      </div>
    </main>
  );
}

function Router() {
  const reportsQuery = useListReports();
  const [complaints, setComplaints] = useState<Complaint[]>([seedComplaint]);
  const [photoPreviews, setPhotoPreviews] = useState<Record<string, string>>({});
  const createReport = useCreateReport({
    mutation: {
      onSuccess: () => {
        void queryClient.invalidateQueries({ queryKey: getListReportsQueryKey() });
      },
    },
  });

  useEffect(() => {
    if (!reportsQuery.data) return;
    const serverComplaints: Complaint[] = reportsQuery.data.map((report) => ({
      id: report.id,
      issueType: report.issueType,
      title: report.aiSummaryTitle,
      description: report.description,
      location: report.location,
      submittedBy: 'San José resident',
      submittedAt: report.createdAt,
      status: 'Needs review',
      priority: report.issueType === 'Obstructed sidewalk' ? 'High' : 'Medium',
      accessibilityImpact: report.issueType === 'Obstructed sidewalk',
      photoPreview: photoPreviews[report.id],
      aiSummary: report.aiSummaryTitle,
      reviewerNote: '',
      contactPreference: report.contactPreference,
    }));
    setComplaints([...serverComplaints, seedComplaint]);
  }, [reportsQuery.data, photoPreviews]);

  const createComplaint = async (draft: DraftSubmission) => {
    const report = await createReport.mutateAsync({
      data: {
        issueType: draft.issueType,
        location: draft.location,
        description: draft.description,
        contactPreference: draft.contactPreference as 'Email' | 'Phone' | 'No follow-up',
      },
    });
    if (draft.photoPreview) {
      setPhotoPreviews((current) => ({ ...current, [report.id]: draft.photoPreview as string }));
    }
    return report;
  };

  const updateComplaint = (id: string, changes: Partial<Complaint>) => {
    setComplaints((current) => current.map((complaint) => complaint.id === id ? { ...complaint, ...changes } : complaint));
  };

  return (
    <AppShell>
      <Switch>
        <Route path="/"><ResidentPage complaints={complaints} onSubmit={createComplaint} /></Route>
        <Route path="/review"><ReviewPage complaints={complaints} updateComplaint={updateComplaint} /></Route>
        <Route path="/records"><RecordsPage /></Route>
        <Route component={NotFound} />
      </Switch>
    </AppShell>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}>
          <ErrorBoundary resetKey={window.location.pathname}><Router /></ErrorBoundary>
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;